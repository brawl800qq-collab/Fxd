package com.alex.assistant

import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL

/** Groq: very fast Whisper speech-to-text + vision chat (OpenAI-compatible API). */
object GroqClient {
    private const val BASE = "https://api.groq.com/openai/v1"

    private fun read(conn: HttpURLConnection): String {
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val body = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
        if (code !in 200..299) throw GeminiClient.GeminiException(code, body.take(300))
        return body
    }

    fun transcribe(key: String, wav: ByteArray): String {
        val boundary = "----alex" + System.currentTimeMillis()
        val out = ByteArrayOutputStream()
        fun w(s: String) = out.write(s.toByteArray(Charsets.UTF_8))
        fun field(n: String, v: String) =
            w("--$boundary\r\nContent-Disposition: form-data; name=\"$n\"\r\n\r\n$v\r\n")
        field("model", "whisper-large-v3-turbo")
        field("language", "ru")
        field("response_format", "json")
        field("temperature", "0")
        field("prompt", "Алекс, открой приложение. Алекс, привет.")
        w("--$boundary\r\nContent-Disposition: form-data; name=\"file\"; filename=\"a.wav\"\r\nContent-Type: audio/wav\r\n\r\n")
        out.write(wav)
        w("\r\n--$boundary--\r\n")

        val conn = URL("$BASE/audio/transcriptions").openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 15000
            conn.readTimeout = 30000
            conn.doOutput = true
            conn.setRequestProperty("Authorization", "Bearer $key")
            conn.setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
            conn.outputStream.use { it.write(out.toByteArray()) }
            return JSONObject(read(conn)).optString("text", "")
        } finally {
            conn.disconnect()
        }
    }

    fun chat(key: String, model: String, system: String, text: String, jpeg: ByteArray?, effort: String? = null): String {
        val content: Any = if (jpeg == null) text else JSONArray()
            .put(JSONObject().put("type", "text").put("text", text))
            .put(
                JSONObject().put("type", "image_url").put(
                    "image_url",
                    JSONObject().put("url", "data:image/jpeg;base64," + Base64.encodeToString(jpeg, Base64.NO_WRAP))
                )
            )
        val body = JSONObject()
            .put("model", model)
            .put(
                "messages", JSONArray()
                    .put(JSONObject().put("role", "system").put("content", system))
                    .put(JSONObject().put("role", "user").put("content", content))
            )
            .put("temperature", 0.3)
            .put("max_tokens", 600)
        if (effort != null) body.put("reasoning_effort", effort)

        val conn = URL("$BASE/chat/completions").openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 15000
            conn.readTimeout = 45000
            conn.doOutput = true
            conn.setRequestProperty("Authorization", "Bearer $key")
            conn.setRequestProperty("Content-Type", "application/json")
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            return JSONObject(read(conn)).getJSONArray("choices").getJSONObject(0)
                .getJSONObject("message").optString("content", "")
        } finally {
            conn.disconnect()
        }
    }

    fun listModels(key: String): List<String> {
        val conn = URL("$BASE/models").openConnection() as HttpURLConnection
        try {
            conn.connectTimeout = 15000
            conn.readTimeout = 15000
            conn.setRequestProperty("Authorization", "Bearer $key")
            val arr = JSONObject(read(conn)).getJSONArray("data")
            val out = ArrayList<String>()
            for (i in 0 until arr.length()) out.add(arr.getJSONObject(i).optString("id"))
            return out
        } finally {
            conn.disconnect()
        }
    }
}
