package com.alex.assistant

import android.content.Context

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("alex_prefs", Context.MODE_PRIVATE)
    fun apiKey(c: Context): String = sp(c).getString("key", "") ?: ""
    fun setApiKey(c: Context, v: String) = sp(c).edit().putString("key", v.trim()).apply()
    fun model(c: Context): String = sp(c).getString("model", "gemini-flash-latest") ?: "gemini-flash-latest"
    fun setModel(c: Context, v: String) = sp(c).edit().putString("model", v.trim()).apply()
    fun voice(c: Context): Int = sp(c).getInt("voice", 0)
    fun setVoice(c: Context, i: Int) = sp(c).edit().putInt("voice", i).apply()
    fun groqKey(c: Context): String = sp(c).getString("groq", "") ?: ""
    fun setGroqKey(c: Context, v: String) = sp(c).edit().putString("groq", v.trim()).apply()
    fun groqModel(c: Context): String =
        sp(c).getString("gmodel", "qwen/qwen3.8-27b") ?: "qwen/qwen3.8-27b"
    fun setGroqModel(c: Context, v: String) = sp(c).edit().putString("gmodel", v.trim()).apply()
    fun groqTextModel(c: Context): String = sp(c).getString("gtext", "llama-3.3-70b-versatile") ?: "llama-3.3-70b-versatile"
    fun setGroqTextModel(c: Context, v: String) = sp(c).edit().putString("gtext", v.trim()).apply()
    /** 0 = screenshot + coordinates, 1 = list of elements */
    fun mode(c: Context): Int = sp(c).getInt("mode", 0)
    fun setMode(c: Context, v: Int) = sp(c).edit().putInt("mode", v).apply()
}
