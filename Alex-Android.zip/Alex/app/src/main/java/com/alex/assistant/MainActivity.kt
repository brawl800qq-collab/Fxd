package com.alex.assistant

import android.Manifest
import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.animation.ValueAnimator
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var etGroq: EditText
    private lateinit var etKey: EditText
    private lateinit var etModel: EditText
    private lateinit var stMic: TextView
    private lateinit var stOverlay: TextView
    private lateinit var stAcc: TextView
    private lateinit var btnStart: Button
    private lateinit var btnMode: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        etGroq = findViewById(R.id.etGroq)
        etKey = findViewById(R.id.etKey)
        etModel = findViewById(R.id.etModel)
        stMic = findViewById(R.id.stMic)
        stOverlay = findViewById(R.id.stOverlay)
        stAcc = findViewById(R.id.stAcc)
        btnStart = findViewById(R.id.btnStart)
        btnMode = findViewById(R.id.btnMode)
        btnMode.setOnClickListener {
            Prefs.setMode(this, if (Prefs.mode(this) == 0) 1 else 0)
            refresh()
        }

        etGroq.setText(Prefs.groqKey(this))
        etKey.setText(Prefs.apiKey(this))
        etModel.setText(Prefs.model(this))

        findViewById<Button>(R.id.btnGetKey).setOnClickListener {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://console.groq.com/keys")))
        }
        findViewById<Button>(R.id.btnSave).setOnClickListener {
            Prefs.setGroqKey(this, etGroq.text.toString())
            Prefs.setApiKey(this, etKey.text.toString())
            Prefs.setModel(this, etModel.text.toString().ifBlank { "gemini-flash-latest" })
            Toast.makeText(this, "Сохранено", Toast.LENGTH_SHORT).show()
            refresh()
        }
        findViewById<Button>(R.id.btnMic).setOnClickListener {
            ActivityCompat.requestPermissions(
                this, arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS), 1
            )
        }
        findViewById<Button>(R.id.btnOverlay).setOnClickListener {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        findViewById<Button>(R.id.btnAcc).setOnClickListener {
            Toast.makeText(this, "Найди «Alex» и включи", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        btnStart.setOnClickListener {
            if (AlexService.running) {
                startService(Intent(this, AlexService::class.java).setAction(AlexService.ACTION_STOP))
            } else {
                Prefs.setGroqKey(this, etGroq.text.toString())
            Prefs.setApiKey(this, etKey.text.toString())
                Prefs.setModel(this, etModel.text.toString().ifBlank { "gemini-flash-latest" })
                try {
                        ContextCompat.startForegroundService(this, Intent(this, AlexService::class.java))
                    } catch (e: Throwable) {
                        Toast.makeText(this, "Не удалось запустить: ${e.message}", Toast.LENGTH_LONG).show()
                    }
            }
            btnStart.postDelayed({ refresh() }, 500)
        }

        ObjectAnimator.ofPropertyValuesHolder(
            findViewById<View>(R.id.logoRing),
            PropertyValuesHolder.ofFloat("scaleX", 1f, 1.25f),
            PropertyValuesHolder.ofFloat("scaleY", 1f, 1.25f),
            PropertyValuesHolder.ofFloat("alpha", 0.45f, 0.1f)
        ).apply { duration = 1400; repeatCount = ValueAnimator.INFINITE; repeatMode = ValueAnimator.REVERSE; start() }
    }

    override fun onResume() { super.onResume(); refresh() }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        refresh()
    }

    private fun accEnabled(): Boolean {
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
        return s.contains("$packageName/")
    }

    private fun refresh() {
        btnMode.text = if (Prefs.mode(this) == 0) "📸 Режим: скриншот и координаты (точно, для игр и видео)"
        else "🧾 Режим: список элементов (экономит лимит)"
        val mic = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        val ov = Settings.canDrawOverlays(this)
        val acc = accEnabled()
        stMic.text = if (mic) "✅ Разрешено" else "⚠️ Нужно разрешение"
        stOverlay.text = if (ov) "✅ Разрешено" else "⚠️ Нужно разрешение"
        stAcc.text = if (acc) "✅ Включено — Алекс видит экран и управляет телефоном"
        else "⚠️ Выключено — Алекс сможет только отвечать голосом"
        val ready = mic && ov && (etGroq.text.isNotBlank() || etKey.text.isNotBlank())
        btnStart.isEnabled = ready || AlexService.running
        btnStart.alpha = if (btnStart.isEnabled) 1f else 0.4f
        btnStart.text = if (AlexService.running) "Остановить Алекса" else "Запустить Алекса"
    }
}
