package com.alex.assistant

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.media.AudioManager
import android.view.KeyEvent
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream

interface AgentHost {
    fun say(text: String)
    fun status(text: String)
    fun ghost(on: Boolean)
    fun heard(text: String)
    fun finished()
}

class Agent(private val ctx: Context, private val host: AgentHost) {
    @Volatile var cancelled = false
    @Volatile var running = false
    @Volatile var engaged = false
    private val memory = ArrayList<String>()

    companion object {
        private val WAKE = Regex("(?iu)(?<!\\p{L})(алекс|алёкс|alex|алэкс|олекс|элекс)\\p{L}?")
        private val JUNK = listOf("продолжение следует", "спасибо за просмотр", "субтитры", "подписывайтесь", "редактор субтитров")

        private const val SYSTEM_TREE = """Ты — Алекс, умный и быстрый голосовой помощник на Android-телефоне. Говори по-русски, коротко и дружелюбно (1-2 предложения), ответ озвучивается вслух.
Экран телефона тебе описывают списком элементов: [номер] значок подпись. Значки: ✎ поле ввода, ▣ кнопка или нажимаемый элемент, · обычный текст.
Выполняй задачу по ОДНОМУ действию за шаг. Отвечай ТОЛЬКО одним JSON-объектом без пояснений:
{"speech":"что сказать вслух","action":"...","id":0,"text":"","app":"","x":0,"y":0,"x2":0,"y2":0}
action: click (id — номер элемента), set_text (id — номер поля ввода, text — что ввести), enter, open_app (app — название приложения), back, home, recents, scroll_down, scroll_up, media (text: pause|play|playpause|next|prev), volume (text: up|down), double_tap и long_press (x,y), wait, look (прислать скриншот, если по списку непонятно: игры, видео, картинки), tap и swipe (x,y 0..1000 по скриншоту), done.
Правила:
- Вопрос или разговор — сразу action=done и ответ в speech.
- Приложения открывай через open_app.
- Для нажатий используй click с номером из списка, а не координаты.
- Чтобы что-то найти: click на поиск, потом set_text в поле, потом enter.
- Если нужного элемента в списке нет — scroll_down или look.
- Задача выполнена — action=done и короткий итог в speech.
- Не повторяй действие, которое не помогло.
- Перед необратимыми действиями (оплата, перевод денег, удаление) не делай их, а спроси подтверждение через action=done.
- speech на промежуточных шагах пустой или очень короткий."""

        private const val SYSTEM_COORD = """Ты — Алекс, умный и быстрый голосовой помощник на Android-телефоне. Говори по-русски, коротко и дружелюбно (1-2 предложения), ответ озвучивается вслух.
Тебе дают задачу и скриншот экрана. На скриншот нанесена сетка: числа сверху — координата x, числа слева — координата y (система 0..1000, слева-сверху 0,0). Находи цель по сетке и называй координаты ЦЕНТРА нужной кнопки или объекта как можно точнее.
Выполняй задачу по ОДНОМУ действию за шаг. Отвечай ТОЛЬКО одним JSON-объектом без пояснений:
{"speech":"что сказать вслух","action":"...","x":0,"y":0,"x2":0,"y2":0,"ms":0,"text":"","app":""}
action: tap (x,y), double_tap (x,y), long_press (x,y), swipe (из x,y в x2,y2; ms — длительность в мс, по умолчанию 400, для удержания в играх 800-2500), type (text — вписать в поле; сначала tap по полю), enter, open_app (app — название приложения), back, home, recents, scroll_down, scroll_up, media (text: pause|play|playpause|next|prev), volume (text: up|down), wait, done.
Правила:
- Вопрос или разговор — сразу action=done и ответ в speech.
- Приложения открывай через open_app.
- Видео или музыка на паузу: action=media, text=pause. Если не помогло — tap по центру видео, затем tap по кнопке паузы.
- В играх нажимай ровно в центр нужной кнопки или объекта, для движения используй swipe с длинным ms.
- Не нажимай ничего лишнего. Один шаг — одно точное действие.
- Задача выполнена — action=done и короткий итог в speech.
- Не повторяй действие, которое не помогло, попробуй другие координаты.
- Перед необратимыми действиями (оплата, перевод денег, удаление) не делай их, а спроси подтверждение через action=done.
- speech на промежуточных шагах пустой или очень короткий."""
    }

    @Synchronized
    fun claim(): Boolean {
        if (running) return false
        running = true
        cancelled = false
        return true
    }

    private fun sys() = if (Prefs.mode(ctx) == 0) SYSTEM_COORD else SYSTEM_TREE

    private fun groqMode() = Prefs.groqKey(ctx).isNotBlank()

    /** Must be called after claim() returned true. */
    fun run(audio: ByteArray, forced: Boolean) {
        engaged = false
        try {
            if (groqMode()) processGroq(audio, forced) else processGemini(audio, forced)
        } catch (e: GeminiClient.GeminiException) {
            val msg = when (e.code) {
                429 -> "Лимит бесплатных запросов закончился. Подожди минутку."
                401, 403 -> "ИИ не принял ключ. Проверь ключ в приложении."
                404 -> "Не нашёл подходящую модель ИИ. Напиши об этом Claude."
                else -> "Ошибка ИИ ${e.code}."
            }
            if (engaged || forced) host.say(msg) else host.status(msg)
        } catch (e: java.io.IOException) {
            if (engaged || forced) host.say("Нет связи с интернетом.") else host.status("Нет связи с интернетом")
        } catch (e: Exception) {
            if (engaged || forced) host.say("Что-то пошло не так.") else host.status("Ошибка обработки")
        } finally {
            running = false
            host.finished()
        }
    }

    // ------------------------------------------------------------ Groq: Whisper -> wake word -> LLM

    private fun processGroq(audio: ByteArray, forced: Boolean) {
        val gkey = Prefs.groqKey(ctx)
        host.status("Распознаю…")
        val text = GroqClient.transcribe(gkey, audio).trim()
        val low = text.lowercase()
        if (text.length < 2 || JUNK.any { low.contains(it) }) { host.status("Слушаю…"); return }

        val m = WAKE.find(text)
        var cmd: String
        if (m != null) {
            val after = text.substring(m.range.last + 1).trim(' ', ',', '.', '!', '?', ':', '-', '—')
            val before = text.substring(0, m.range.first).trim(' ', ',', '.', '!', '?', ':', '-', '—')
            cmd = if (after.isNotBlank()) after else before
        } else if (forced) {
            cmd = text
        } else {
            host.status("Услышал, но не мне: «" + text.take(40) + "»")
            return
        }
        cmd = cmd.trim(' ', ',', '.', '!', '?', ':', '-', '—')
        engaged = true
        if (cmd.isBlank()) { host.say("Слушаю"); return }
        host.heard(cmd)
        loop(cmd)
    }

    // ------------------------------------------------------------ Gemini fallback (audio straight to Gemini)

    private fun processGemini(audio: ByteArray, forced: Boolean) {
        val key = Prefs.apiKey(ctx)
        if (key.isBlank()) { host.say("Вставь ключ Groq или Gemini в настройках приложения."); return }
        host.status("Слушаю…")
        val intro = StringBuilder()
        if (memory.isNotEmpty()) intro.append("Недавний разговор:\n").append(memory.joinToString("\n")).append("\n\n")
        intro.append("К сообщению приложена запись голоса пользователя. Добавь в JSON поля \"heard\" (дословный текст речи) и \"for_alex\" (true/false). ")
        intro.append(
            if (forced) "Пользователь сам нажал кнопку, поэтому for_alex=true. "
            else "for_alex=true только если пользователь обращается к Алексу (звучит имя «Алекс»/«Alex») или явно продолжает диалог; фоновые разговоры и шум — for_alex=false (action=done). "
        )
        intro.append("Если это просто вопрос — ответь в speech и action=done. Если нужно действовать на телефоне — action=look.")
        val j = parse(askGemini(key, intro.toString(), null, audio))
        val heard = j.optString("heard", "").trim()
        val forAlex = forced || j.optBoolean("for_alex", false)
        if (!forAlex) {
            host.status(if (heard.isBlank()) "Слушаю…" else "Услышал, но не мне: «" + heard.take(40) + "»")
            return
        }
        if (heard.isBlank()) { host.status("Не расслышал"); return }
        engaged = true
        host.heard(heard)
        val action = j.optString("action", "done")
        val speech = j.optString("speech", "").trim()
        if (action == "done" || action == "none" || action == "") {
            if (speech.isNotEmpty()) host.say(speech)
            remember(heard, speech)
            return
        }
        loop(heard)
    }

    private fun askGemini(key: String, text: String, jpeg: ByteArray?, audio: ByteArray? = null): String {
        val saved = Prefs.model(ctx)
        val cands = listOf(saved, "gemini-flash-latest", "gemini-3-flash-preview", "gemini-3.1-flash-lite", "gemini-2.5-flash").distinct()
        var last: GeminiClient.GeminiException? = null
        for (m in cands) {
            try {
                val r = GeminiClient.generate(key, m, sys(), text, jpeg, audio)
                if (m != saved) Prefs.setModel(ctx, m)
                return r
            } catch (e: GeminiClient.GeminiException) {
                if (e.code == 404) { last = e; continue }
                throw e
            }
        }
        throw last ?: GeminiClient.GeminiException(404, "no model")
    }

    private fun modelProblem(e: GeminiClient.GeminiException): Boolean {
        val msg = (e.message ?: "").lowercase()
        return e.code == 404 ||
            (e.code == 400 && (msg.contains("decommission") || msg.contains("does not exist") || msg.contains("not found") ||
                (msg.contains("image") && msg.contains("support"))))
    }

    private fun tryGroq(key: String, m: String, text: String, jpeg: ByteArray?): String {
        val effort = when {
            m.contains("qwen") -> "none"
            m.contains("gpt-oss") -> "low"
            else -> null
        }
        if (effort != null) {
            try {
                return GroqClient.chat(key, m, sys(), text, jpeg, effort)
            } catch (e: GeminiClient.GeminiException) {
                if (e.code != 400 || modelProblem(e)) throw e
            }
        }
        return GroqClient.chat(key, m, sys(), text, jpeg, null)
    }

    private val visionModels = listOf("qwen/qwen3.8-27b", "qwen/qwen3.6-27b",
        "meta-llama/llama-4-scout-17b-16e-instruct", "meta-llama/llama-4-maverick-17b-128e-instruct")
    private val textModels = listOf("llama-3.3-70b-versatile", "openai/gpt-oss-120b", "openai/gpt-oss-20b",
        "qwen/qwen3-32b", "llama-3.1-8b-instant")

    /** Tries models one by one. Limits are per model, so on 429 or a missing model we move to the next. */
    private fun askGroq(text: String, jpeg: ByteArray?): String {
        val key = Prefs.groqKey(ctx)
        val vision = jpeg != null
        val saved = if (vision) Prefs.groqModel(ctx) else Prefs.groqTextModel(ctx)
        val queue = ArrayDeque<String>()
        queue.add(saved)
        queue.addAll(if (vision) visionModels else textModels + visionModels)
        val tried = HashSet<String>()
        var discovered = false
        var last: GeminiClient.GeminiException? = null
        while (queue.isNotEmpty()) {
            val m = queue.removeFirst()
            if (!tried.add(m)) continue
            try {
                val r = tryGroq(key, m, text, jpeg)
                if (m != saved) { if (vision) Prefs.setGroqModel(ctx, m) else Prefs.setGroqTextModel(ctx, m) }
                return r
            } catch (e: GeminiClient.GeminiException) {
                if (!modelProblem(e) && e.code != 429) throw e
                last = e
                if (queue.isEmpty() && !discovered) {
                    discovered = true
                    try {
                        val hints = if (vision) listOf("qwen", "llama-4", "vision", "-vl", "scout", "maverick")
                        else listOf("llama", "gpt-oss", "qwen", "kimi")
                        GroqClient.listModels(key)
                            .filter { id -> !tried.contains(id) && hints.any { id.contains(it) } &&
                                !id.contains("whisper") && !id.contains("guard") && !id.contains("tts") &&
                                !id.contains("orpheus") && !id.contains("safeguard") }
                            .forEach { queue.add(it) }
                    } catch (_: Exception) {}
                }
            }
        }
        throw last ?: GeminiClient.GeminiException(404, "no model")
    }

    private fun llm(text: String, jpeg: ByteArray?): String =
        if (groqMode()) askGroq(text, jpeg) else askGemini(Prefs.apiKey(ctx), text, jpeg, null)

    // ------------------------------------------------------------ action loop

    private fun remember(goal: String, speech: String) {
        memory.add("Пользователь: $goal")
        if (speech.isNotEmpty()) memory.add("Алекс: $speech")
        while (memory.size > 8) memory.removeAt(0)
    }

    private val LOCAL = listOf(
        Regex("(?iu)^\\W*(поставь\\s+(видео\\s+|музыку\\s+)?на\\s+пауз\\w*|пауза|останови(\\s+(видео|музыку|воспроизведение))?|pause)\\W*$") to "pause",
        Regex("(?iu)^\\W*(продолжи(\\s+(видео|музыку|воспроизведение))?|включи\\s+(видео|музыку)|сними\\s+с\\s+паузы|play|воспроизведи)\\W*$") to "play",
        Regex("(?iu)^\\W*(следующ\\w+(\\s+(трек|видео|песн\\w+))?|дальше|next)\\W*$") to "next",
        Regex("(?iu)^\\W*(предыдущ\\w+(\\s+(трек|видео|песн\\w+))?|прошлый\\s+трек|previous)\\W*$") to "prev",
        Regex("(?iu)^\\W*(сделай\\s+)?громче\\W*$") to "volup",
        Regex("(?iu)^\\W*(сделай\\s+)?тише\\W*$") to "voldown",
        Regex("(?iu)^\\W*(назад|вернись)\\W*$") to "back",
        Regex("(?iu)^\\W*(домой|на\\s+главный\\s+экран|на\\s+рабочий\\s+стол)\\W*$") to "home"
    )

    private fun mediaKey(name: String) {
        val code = when (name.lowercase()) {
            "pause" -> KeyEvent.KEYCODE_MEDIA_PAUSE
            "play" -> KeyEvent.KEYCODE_MEDIA_PLAY
            "next" -> KeyEvent.KEYCODE_MEDIA_NEXT
            "prev", "previous" -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
            "stop" -> KeyEvent.KEYCODE_MEDIA_STOP
            else -> KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE
        }
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }

    private fun volume(up: Boolean) {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.adjustStreamVolume(
            AudioManager.STREAM_MUSIC,
            if (up) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER,
            AudioManager.FLAG_SHOW_UI
        )
    }

    /** Instant commands without any AI request. */
    private fun localCommand(cmd: String): Boolean {
        val c = cmd.trim().lowercase()
        if (c.length > 45) return false
        val hit = LOCAL.firstOrNull { it.first.containsMatchIn(c) }?.second ?: return false
        val acc = AlexAccessibilityService.instance
        when (hit) {
            "pause" -> { mediaKey("pause"); host.say("Пауза.") }
            "play" -> { mediaKey("play"); host.say("Продолжаю.") }
            "next" -> { mediaKey("next"); host.say("Дальше.") }
            "prev" -> { mediaKey("prev"); host.say("Назад.") }
            "volup" -> { volume(true); host.say("Громче.") }
            "voldown" -> { volume(false); host.say("Тише.") }
            "back" -> { if (acc == null) return false; acc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK); host.say("Хорошо.") }
            "home" -> { if (acc == null) return false; acc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME); host.say("Хорошо.") }
            else -> return false
        }
        return true
    }

    private fun <T> withGhost(extraMs: Long = 0, block: () -> T): T {
        host.ghost(true)
        Thread.sleep(150)
        try { return block() } finally { Thread.sleep(250 + extraMs); host.ghost(false) }
    }

    private fun loop(goal: String) {
        if (localCommand(goal)) { remember(goal, ""); return }
        val acc = AlexAccessibilityService.instance
        val dm = ctx.resources.displayMetrics
        val mode = Prefs.mode(ctx)
        val history = ArrayList<String>()
        var lastSpeech = ""
        var wantShot = false
        val maxSteps = if (acc == null) 1 else 10
        var step = 0

        while (step < maxSteps) {
            step++
            if (cancelled) { host.say("Остановился."); break }
            var screen: String? = null
            var jpeg: ByteArray? = null
            var w = dm.widthPixels
            var h = dm.heightPixels
            if (acc != null) {
                if (mode == 0) wantShot = true
                else {
                    host.status("Читаю экран…")
                    screen = acc.describeScreen()
                    if (screen == null) wantShot = true
                }
                if (wantShot) {
                    host.status("Смотрю на экран…")
                    host.ghost(true); Thread.sleep(220)
                    val bmp = acc.screenshotBlocking()
                    host.ghost(false)
                    if (bmp != null) { w = bmp.width; h = bmp.height; jpeg = toJpeg(bmp, true) }
                    wantShot = false
                }
            }
            if (cancelled) { host.say("Остановился."); break }
            host.status("Думаю…")
            val j = parse(llm(prompt(goal, step, history, screen, jpeg != null, acc != null, mode), jpeg))
            val speech = j.optString("speech", "").trim()
            if (speech.isNotEmpty()) { host.say(speech); lastSpeech = speech }
            val action = j.optString("action", "done")
            if (action == "done" || action == "none" || action == "" || acc == null) break
            if (action == "look") { wantShot = true; history.add("запросил скриншот"); continue }
            if (cancelled) { host.say("Остановился."); break }

            host.status("Делаю: $action")
            val id = j.optInt("id", -1)
            val ms = j.optLong("ms", 0L)
            val desc: String = when (action) {
                "click" -> {
                    if (acc.clickId(id)) "нажал [$id]"
                    else {
                        val c = acc.centerOf(id)
                        if (c != null) { withGhost { acc.tap(c.first, c.second) }; "тапнул [$id]" }
                        else "элемент [$id] не найден"
                    }
                }
                "set_text" -> {
                    val t = j.optString("text", "")
                    if (acc.setTextId(id, t) || acc.typeText(t)) "ввёл «$t»" else "не смог ввести текст"
                }
                "tap" -> { withGhost { acc.tap(cx(j, "x", w), cx(j, "y", h)) }; "нажал (${j.optInt("x")},${j.optInt("y")})" }
                "double_tap" -> { withGhost(200) { acc.doubleTap(cx(j, "x", w), cx(j, "y", h)) }; "двойной тап (${j.optInt("x")},${j.optInt("y")})" }
                "long_press" -> { withGhost(900) { acc.longPress(cx(j, "x", w), cx(j, "y", h)) }; "долгое нажатие (${j.optInt("x")},${j.optInt("y")})" }
                "swipe" -> {
                    val d = if (ms > 0) ms else 400L
                    withGhost(d) { acc.swipe(cx(j, "x", w), cx(j, "y", h), cx(j, "x2", w), cx(j, "y2", h), d) }
                    "свайп"
                }
                "scroll_down" -> {
                    if (!acc.scroll(true)) withGhost(400) { acc.swipe(w * .5f, h * .72f, w * .5f, h * .28f) }
                    "прокрутил вниз"
                }
                "scroll_up" -> {
                    if (!acc.scroll(false)) withGhost(400) { acc.swipe(w * .5f, h * .28f, w * .5f, h * .72f) }
                    "прокрутил вверх"
                }
                "media" -> { mediaKey(j.optString("text", "playpause")); "медиа-кнопка ${j.optString("text")}" }
                "volume" -> { volume(j.optString("text", "up") != "down"); "громкость ${j.optString("text")}" }
                "type" -> {
                    val t = j.optString("text", "")
                    if (acc.typeText(t)) "ввёл «$t»" else "не смог ввести текст"
                }
                "enter" -> if (acc.pressEnter()) "нажал Enter" else "Enter не сработал"
                "open_app" -> {
                    val a = j.optString("app", "")
                    if (acc.openApp(a)) "открыл приложение $a" else "приложение $a не найдено"
                }
                "back" -> { acc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK); "назад" }
                "home" -> { acc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME); "домой" }
                "recents" -> { acc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_RECENTS); "недавние" }
                "wait" -> { Thread.sleep(1500); "подождал" }
                else -> "неизвестное действие $action"
            }
            history.add(desc)
            Thread.sleep(800)
        }
        remember(goal, lastSpeech)
    }

    private fun prompt(goal: String, step: Int, history: List<String>, screen: String?, hasImage: Boolean, canSee: Boolean, mode: Int): String {
        val sb = StringBuilder()
        if (memory.isNotEmpty()) sb.append("Недавний разговор:\n").append(memory.takeLast(6).joinToString("\n")).append("\n\n")
        sb.append("Задача пользователя: ").append(goal).append("\n")
        if (screen != null) sb.append("Экран сейчас:\n").append(screen)
        when {
            hasImage -> sb.append("Приложен текущий скриншот экрана с сеткой координат (0..1000).\n")
            !canSee -> sb.append("Управление телефоном не включено — только отвечай словами.\n")
            mode == 0 -> sb.append("Скриншот сделать не удалось (экран защищён?). Скажи об этом пользователю: action=done.\n")
            screen == null -> sb.append("Список элементов пуст, скриншота нет — верни action=look.\n")
        }
        if (history.isNotEmpty()) sb.append("Уже сделано: ").append(history.takeLast(8).joinToString("; ")).append("\n")
        sb.append("Шаг ").append(step).append(". Верни JSON со следующим действием.")
        return sb.toString()
    }

    private fun parse(raw: String): JSONObject {
        val s = raw.replace(Regex("(?s)<think>.*?</think>"), "").trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        return try {
            if (s.startsWith("[")) JSONArray(s).getJSONObject(0) else JSONObject(s)
        } catch (e: Exception) {
            try {
                JSONObject(s.substring(s.indexOf('{'), s.lastIndexOf('}') + 1))
            } catch (e2: Exception) {
                JSONObject().put("speech", s).put("action", "done")
            }
        }
    }

    private fun cx(j: JSONObject, k: String, size: Int): Float =
        (j.optDouble(k, 500.0) / 1000.0 * size).toFloat().coerceIn(0f, size - 1f)

    private fun toJpeg(src: Bitmap, grid: Boolean): ByteArray {
        val max = 800f
        val scale = minOf(1f, max / maxOf(src.width, src.height))
        val nw = maxOf(1, (src.width * scale).toInt())
        val nh = maxOf(1, (src.height * scale).toInt())
        val b = Bitmap.createScaledBitmap(src, nw, nh, true).copy(Bitmap.Config.ARGB_8888, true)
        if (grid) drawGrid(b)
        val out = ByteArrayOutputStream()
        b.compress(Bitmap.CompressFormat.JPEG, 65, out)
        return out.toByteArray()
    }

    private fun drawGrid(b: Bitmap) {
        val c = Canvas(b)
        val w = b.width.toFloat()
        val h = b.height.toFloat()
        val line = Paint().apply { color = 0x66FFEB3B; strokeWidth = 1f }
        val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = maxOf(12f, w / 40f)
            setShadowLayer(3f, 0f, 0f, Color.BLACK)
        }
        for (i in 1..9) {
            val x = w * i / 10f
            val y = h * i / 10f
            c.drawLine(x, 0f, x, h, line)
            c.drawLine(0f, y, w, y, line)
            c.drawText((i * 100).toString(), x + 2f, txt.textSize, txt)
            c.drawText((i * 100).toString(), 2f, y - 2f, txt)
        }
    }
}
