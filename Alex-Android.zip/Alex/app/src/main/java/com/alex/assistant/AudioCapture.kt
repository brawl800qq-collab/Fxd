package com.alex.assistant

import android.annotation.SuppressLint
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

/** Own microphone capture. Cuts speech into segments, normalizes volume, returns WAV. */
class AudioCapture(
    private val onSegment: (ByteArray) -> Unit,
    private val onLevel: (Float) -> Unit,
    private val onVoice: (Boolean) -> Unit,
    private val onError: (String) -> Unit
) {
    @Volatile var paused = false
    @Volatile private var alive = false

    companion object {
        const val RATE = 16000
        private const val FRAME = 320 // 20 ms
        private const val END_SILENCE_MS = 800
        private const val MAX_MS = 15000
        private const val MIN_VOICED_MS = 200
    }

    fun start() {
        if (alive) return
        alive = true
        Thread {
            while (alive) {
                try { runOnce() } catch (e: Throwable) { onError("Ошибка микрофона: ${e.message}") }
                if (alive) try { Thread.sleep(1000) } catch (_: Throwable) {}
            }
        }.also { it.isDaemon = true }.start()
    }

    fun stop() { alive = false }

    @SuppressLint("MissingPermission")
    private fun runOnce() {
        val min = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val rec = AudioRecord(
            MediaRecorder.AudioSource.MIC, RATE,
            AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(min, 16384)
        )
        try {
            if (rec.state != AudioRecord.STATE_INITIALIZED) { onError("Микрофон недоступен"); return }
            rec.startRecording()
            loop(rec)
        } finally {
            try { rec.stop() } catch (_: Throwable) {}
            try { rec.release() } catch (_: Throwable) {}
        }
    }

    private fun loop(rec: AudioRecord) {
        val buf = ShortArray(FRAME)
        val pre = ArrayDeque<ByteArray>()
        var seg = ByteArrayOutputStream()
        var inSpeech = false
        var voicedMs = 0
        var silenceMs = 0
        var totalMs = 0
        var noise = 100.0
        var tick = 0
        var zeroFrames = 0
        var badReads = 0

        while (alive) {
            val n = rec.read(buf, 0, FRAME)
            if (n <= 0) {
                if (++badReads > 100) { onError("Микрофон не отдаёт звук, пробую заново…"); return }
                try { Thread.sleep(20) } catch (_: Throwable) {}
                continue
            }
            badReads = 0
            var sum = 0.0
            var peak = 0
            for (i in 0 until n) {
                val v = buf[i].toInt()
                sum += v.toDouble() * v
                if (Math.abs(v) > peak) peak = Math.abs(v)
            }
            val rms = Math.sqrt(sum / n)
            if (peak == 0) {
                if (++zeroFrames >= 150) { onError("Микрофон молчит (занят другим приложением?). Пробую заново…"); return }
            } else zeroFrames = 0
            if (++tick % 2 == 0) onLevel(rms.toFloat())

            if (paused) {
                if (inSpeech) onVoice(false)
                inSpeech = false; seg = ByteArrayOutputStream(); pre.clear()
                voicedMs = 0; silenceMs = 0; totalMs = 0
                continue
            }

            val bytes = toBytes(buf, n)
            val thr = maxOf(250.0, noise * 2.8)
            val loud = rms > thr

            if (!inSpeech) {
                noise = minOf(noise * 0.97 + rms * 0.03, 1500.0)
                pre.addLast(bytes)
                if (pre.size > 15) pre.removeFirst()
                if (loud) {
                    inSpeech = true
                    seg = ByteArrayOutputStream()
                    pre.forEach { seg.write(it) }
                    pre.clear()
                    voicedMs = 20; silenceMs = 0; totalMs = 20
                    onVoice(true)
                }
            } else {
                seg.write(bytes)
                totalMs += 20
                if (loud) { voicedMs += 20; silenceMs = 0 } else silenceMs += 20
                if (silenceMs >= END_SILENCE_MS || totalMs >= MAX_MS) {
                    onVoice(false)
                    if (voicedMs >= MIN_VOICED_MS) onSegment(wav(seg.toByteArray()))
                    inSpeech = false; seg = ByteArrayOutputStream()
                    voicedMs = 0; silenceMs = 0; totalMs = 0
                }
            }
        }
    }

    private fun toBytes(s: ShortArray, n: Int): ByteArray {
        val b = ByteBuffer.allocate(n * 2).order(ByteOrder.LITTLE_ENDIAN)
        for (i in 0 until n) b.putShort(s[i])
        return b.array()
    }

    private fun wav(pcmIn: ByteArray): ByteArray {
        // normalize quiet recordings
        val sb = ByteBuffer.wrap(pcmIn).order(ByteOrder.LITTLE_ENDIAN)
        var peak = 1
        for (i in 0 until pcmIn.size / 2) { val v = Math.abs(sb.getShort(i * 2).toInt()); if (v > peak) peak = v }
        val gain = if (peak < 12000) minOf(10.0, 20000.0 / peak) else 1.0
        val pcm = ByteArray(pcmIn.size)
        val ob = ByteBuffer.wrap(pcm).order(ByteOrder.LITTLE_ENDIAN)
        for (i in 0 until pcmIn.size / 2) {
            val v = (sb.getShort(i * 2) * gain).toInt().coerceIn(-32768, 32767)
            ob.putShort(i * 2, v.toShort())
        }
        val b = ByteBuffer.allocate(44 + pcm.size).order(ByteOrder.LITTLE_ENDIAN)
        b.put("RIFF".toByteArray()); b.putInt(36 + pcm.size)
        b.put("WAVE".toByteArray()); b.put("fmt ".toByteArray())
        b.putInt(16); b.putShort(1); b.putShort(1)
        b.putInt(RATE); b.putInt(RATE * 2); b.putShort(2); b.putShort(16)
        b.put("data".toByteArray()); b.putInt(pcm.size); b.put(pcm)
        return b.array()
    }
}
